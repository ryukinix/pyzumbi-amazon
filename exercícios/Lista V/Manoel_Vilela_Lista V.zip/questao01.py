x = 2
y = 5
if y > 8:
	y = 2 * 2
else:
	x = x * 2
print(x + y)