x = 0
for i in range(1, 10):
	if i != 3:
		for j in range(1, 7):
			print('oi')
			x += 1
print("Foi impresso 'oi' %d vezes" %x)